#include "D:\opencv\build\include\opencv2\imgproc\imgproc.hpp"
#include "D:\opencv\build\include\opencv2\imgcodecs\imgcodecs.hpp"
#include "D:\opencv\build\include\opencv2\highgui\highgui.hpp"
#include "D:\opencv\build\include\opencv2\objdetect\objdetect.hpp"
#include <iostream>
#include <iterator>


using namespace std;
using namespace cv;


//Global Variables
Mat img1;
Mat templ;
Mat result;
char* image_window = "Pedestrian Signal";

int match_method;
int max_Trackbar = 5;

// Function Header
void MatchingMethod(int, void*);



class cars     //main class
{
public:	    

	Mat image_input;          //main input image
	Mat image_main_result;    //the final resultant image
	Mat storage;              //to stop detection of same car more than once

	CascadeClassifier cascade;    //the main cascade classifier
	CascadeClassifier checkcascade;        //a test classifier, vehicle detected by both main and test is identified as vehicle

	int num;

	void getimage(Mat src) //getting the input image
	{

		if (!src.data)
		{
			cout << "src not filled" << endl;
		}

		else
		{
			image_input = src.clone();
			storage = src.clone();              //initialising storage
			image_main_result = src.clone();    //initialising result

			//cout << "got image" << endl;
		}
	}


	void cascade_load(string cascade_string)            //loading the main cascade
	{
		cascade.load(cascade_string);

		if (!cascade.load(cascade_string))
		{
			cout << endl << "Could not load classifier cascade" << endl;

		}
	}


	void checkcascade_load(string checkcascade_string)               //loading the test cascade
	{
		checkcascade.load(checkcascade_string);

		if (!checkcascade.load(checkcascade_string))
		{
			cout << endl << "Could not load classifier checkcascade" << endl;

		}
	}


	void display_input()             // function to display input
	{

		namedWindow("display_input");
		imshow("display_input", image_input);

	}

	void display_output()            //function to display output
	{

		if (!image_main_result.empty())
		{
			namedWindow("Car_Pedestrian");
			imshow("Car_Pedestrian", image_main_result);

			//imwrite("D:/Cars/abc.jpg", image_main_result);
		}
	}

	void setnum()
	{
		num = 0;
	}


	void findcars()                 //main function
	{
		int i = 0;

		Mat img = storage.clone();
		Mat temp;                    //If a vehicle is detected(after testing) by one classifier, then it will not be available for other one

		if (img.empty())
		{
			cout << endl << "detect not successful" << endl;
		}
		int cen_x;
		int cen_y;
		vector<Rect> cars;
		const static Scalar colors[] = { CV_RGB(0,0,255),CV_RGB(0,255,0),CV_RGB(255,0,0),CV_RGB(255,255,0),CV_RGB(255,0,255),CV_RGB(0,255,255),CV_RGB(255,255,255),CV_RGB(128,0,0),CV_RGB(0,128,0),CV_RGB(0,0,128),CV_RGB(128,128,128),CV_RGB(0,0,0) };

		Mat gray;

		cvtColor(img, gray, CV_BGR2GRAY);

		Mat resize_image(cvRound(img.rows), cvRound(img.cols), CV_8UC1);

		resize(gray, resize_image, resize_image.size(), 0, 0, INTER_LINEAR);
		equalizeHist(resize_image, resize_image);


		cascade.detectMultiScale(resize_image, cars, 1.1, 2, 0, Size(10, 10));                 //detection using main classifier 


		for (vector<Rect>::const_iterator main = cars.begin(); main != cars.end(); main++, i++)
		{
			Mat resize_image_reg_of_interest;
			vector<Rect> nestedcars;
			Point center;
			Scalar color = colors[i % 8];


			//getting points for bouding a rectangle over the car detected by main
			int x0 = cvRound(main->x);
			int y0 = cvRound(main->y);
			int x1 = cvRound((main->x + main->width - 1));
			int y1 = cvRound((main->y + main->height - 1));


			if (checkcascade.empty())
				continue;
			resize_image_reg_of_interest = resize_image(*main);
			checkcascade.detectMultiScale(resize_image_reg_of_interest, nestedcars, 1.1, 2, 0, Size(30, 30));

			for (vector<Rect>::const_iterator sub = nestedcars.begin(); sub != nestedcars.end(); sub++)      //testing the detected car by main using checkcascade
			{
				center.x = cvRound((main->x + sub->x + sub->width*0.5));        //getting center points for bouding a circle over the car detected by checkcascade
				cen_x = center.x;
				center.y = cvRound((main->y + sub->y + sub->height*0.5));
				cen_y = center.y;
				if (cen_x>(x0 + 15) && cen_x<(x1 - 15) && cen_y>(y0 + 15) && cen_y<(y1 - 15))         //if centre of bounding circle is inside the rectangle boundary over a threshold the the car is certified
				{

					rectangle(image_main_result, cvPoint(x0, y0),
						cvPoint(x1, y1),
						color, 3, 8, 0);               //detecting boundary rectangle over the final result



					//masking the detected car to detect second car if present

					Rect region_of_interest = Rect(x0, y0, x1 - x0, y1 - y0);
					temp = storage(region_of_interest);
					temp = Scalar(255, 255, 255);

					num = num + 1;     //num if number of cars detected

				}
			}

		}


		if (image_main_result.empty())
		{
			cout << endl << "result storage not successful" << endl;
		}

	}


};


void MatchingMethod(int, void*)
{
	/// Source image to display
	Mat img_display;
	img1.copyTo(img_display);

	/// Create the result matrix
	int result_cols = img1.cols - templ.cols + 1;
	int result_rows = img1.rows - templ.rows + 1;

	result.create(result_rows, result_cols, CV_32FC1);

	/// Do the Matching and Normalize
	matchTemplate(img1, templ, result, match_method);
	normalize(result, result, 0, 1, NORM_MINMAX, -1, Mat());

	/// Localizing the best match with minMaxLoc
	double minVal; double maxVal; Point minLoc; Point maxLoc;
	Point matchLoc;

	minMaxLoc(result, &minVal, &maxVal, &minLoc, &maxLoc, Mat());

	if (match_method == CV_TM_SQDIFF || match_method == CV_TM_SQDIFF_NORMED)
	{
		matchLoc = minLoc;
	}
	else
	{
		matchLoc = maxLoc;
	}

	//detecting boundary rectangle
	rectangle(img_display, matchLoc, Point(matchLoc.x + templ.cols, matchLoc.y + templ.rows), Scalar::all(0), 2, 8, 0);
	
	//displaying the resultant image
	imshow(image_window, img_display); 

	return;
}


int main(int argc, const char** argv)
{
	
	//--------------------------------------------Pedestrian Dtection------------------------------------//

	Mat img;
	FILE* f = 0;
	char _filename[1024];

	if (argc == 1)
	{
		cout << "Usage: peopledetect (<image_filename> | <image_list>.txt)" << endl;
		return 0;
	}
	img = imread(argv[1]);

	if (img.data)
	{
		strcpy(_filename, argv[1]);
	}
	else
	{
		f = fopen(argv[1], "rt");
		if (!f)
		{
			cout << stderr << "ERROR: the specified file could not be loaded" << endl;
			return -1;
		}
	}

	HOGDescriptor hog;
	hog.setSVMDetector(HOGDescriptor::getDefaultPeopleDetector());
	

	for (;;)
	{
		char* filename = _filename;
		if (f)
		{
			if (!fgets(filename, (int)sizeof(_filename) - 2, f))
				break;
			
			if (filename[0] == '#')
				continue;
			int l = (int)strlen(filename);
			while (l > 0 && isspace(filename[l - 1]))
				--l;
			filename[l] = '\0';
			img = imread(filename);
		}
		
		if (!img.data)
			continue;

		fflush(stdout);
		vector<Rect> found, found_filtered;
		double t = (double)getTickCount();
	
		hog.detectMultiScale(img, found, 0, Size(8, 8), Size(32, 32), 1.05, 2);
		t = (double)getTickCount() - t;
		//printf("tdetection time = %gms\n", t*1000. / cv::getTickFrequency());
		size_t i, j;
		for (i = 0; i < found.size(); i++)
		{
			Rect r = found[i];
			for (j = 0; j < found.size(); j++)
				if (j != i && (r & found[j]) == r)
					break;
			if (j == found.size())
				found_filtered.push_back(r);
		}
		for (i = 0; i < found_filtered.size(); i++)
		{
			Rect r = found_filtered[i];
			// the HOG detector returns slightly larger rectangles than the real objects.
			// so we slightly shrink the rectangles to get a nicer output.
			r.x += cvRound(r.width*0.1);
			r.width = cvRound(r.width*0.8);
			r.y += cvRound(r.height*0.07);
			r.height = cvRound(r.height*0.8);
			rectangle(img, r.tl(), r.br(), cv::Scalar(0, 255, 0), 3);
		}
		int c = waitKey(0) & 255;
		if (c == 'q' || c == 'Q' || !f)
			break;
	}
	if (f)
		fclose(f);

	//--------------------------------------------Vehicle Detection--------------------------------//

	double t = 0;
	t = (double)cvGetTickCount();              //starting timer
	Mat image;
	resize(img, image, Size(300, 150), 0, 0, INTER_LINEAR);        //resizing the image 
	cars detectcars;                      //creating a object


	string checkcas = argv[3];

	detectcars.getimage(image);           //get the image
	detectcars.setnum();                  //set number of cars detected as 0
	detectcars.checkcascade_load(checkcas);      //load the test cascade

												 //Applying three cascades for a finer search.
	if (argc > 3)
	{
		for (int i = 4;i < argc;i++)
		{
			string cas = argv[i];
			detectcars.cascade_load(cas);
			detectcars.findcars();
		}
	}
	else
	{
	
		cout << endl << "Please provide atleast one main cascade xml file" << endl;
	}

	t = (double)cvGetTickCount() - t;       //stopping the timer

	if (detectcars.num != 0)
	{
		//cout << endl << detectcars.num << " cars got detected in = " << t / ((double)cvGetTickFrequency()*1000.) << " ms" << endl << endl;
		cout << endl << detectcars.num << " cars got detected" << endl << endl;
		
		if (detectcars.num>0)
		{
			cout << "Pedestrian should wait." << endl;
		}
		else
		{
			cout << endl << "Pedestrian can walk now." << endl;

		}
	
	}
	else
	{
		cout << endl << "cars not found" << endl;
	}

	detectcars.display_output();          //displaying the final result

	

	//----------------------------------------Pedestrian Signal Dtection----------------------------------//

	img1 = imread(argv[1], 1);
	templ = imread(argv[2], 1);

	namedWindow(image_window, CV_WINDOW_AUTOSIZE);            // Creating window
	MatchingMethod(0, 0);
	

	waitKey(0);
	return 0;

}

